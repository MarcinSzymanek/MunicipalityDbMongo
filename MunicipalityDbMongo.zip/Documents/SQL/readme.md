In this folder the diagrammes and textexplanation goes
