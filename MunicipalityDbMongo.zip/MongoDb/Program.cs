﻿// See https://aka.ms/new-console-template for more information

using MongoDb;

Console.WriteLine("Hello, World!");

App app = new App();
return app.Run();
