﻿namespace MongoDb.Models;

public class Maintenance
{
    public string Name { get; set; }
    public string Date { get; set; }
}