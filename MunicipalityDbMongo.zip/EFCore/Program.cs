﻿// See https://aka.ms/new-console-template for more information

using EFCore;
using EFCore.data;
using EFCore.Model;



App app = new();
return(app.Run());

