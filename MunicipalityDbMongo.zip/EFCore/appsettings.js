﻿
{
    "ConnectionStrings" : {
        "MyConnString" : "Data Source=127.0.0.1,1433;Database=FacilitiesDb;User Id=sa;Password=MyDumbPass1;TrustServerCertificate=True"
    } 
}
